# __destruct

```php
__destruct ()
```

Destroys the current object and clears memory.